# GitHub upload checklist

Antes de publicar no Streamlit Cloud, confira se o repositorio tem exatamente esta estrutura principal:

```text
.streamlit/
fuzzyswot/
tests/
.gitignore
DEPLOYMENT.md
GITHUB_UPLOAD_CHECKLIST.md
README.md
VERSION.txt
requirements.txt
streamlit_app.py
```

## Ponto critico

No arquivo `streamlit_app.py`, os imports precisam estar assim:

```python
from fuzzyswot.constants import FUZZY_SCALE, HIERARCHY_WEIGHTS, TOWS_MATRIX_NAME
from fuzzyswot.core import (...)
from fuzzyswot.exports import pdf_bytes, write_pdf_report
from fuzzyswot.models import Evaluator, Project
```

Se aparecer algo como `from core import`, `from constants import`, `from exports import` ou `from models import`, o app publicado vai quebrar.

## Como corrigir o erro atual

1. No GitHub, abra o repositorio `FuzzySWOT`.
2. Apague arquivos antigos soltos como `core.py`, `constants.py`, `exports.py` e `models.py` se eles estiverem na raiz.
3. Envie a pasta `fuzzyswot/` completa.
4. Substitua o `streamlit_app.py` pelo arquivo deste pacote.
5. Clique em `Commit changes`.
6. No Streamlit Cloud, clique em `Manage app` e depois `Reboot app`.
